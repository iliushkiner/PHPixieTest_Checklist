<?php

return [
    [
        'id'     => 1,
        'userId' => 1,
        'text'   => "Hello World!",
        'date'   => '2016-12-01 10:15:00'
    ],
    [
        'id'     => 2,
        'userId' => 1,
        'text'   => "Talk is cheap. Show me the code. -- Linus Torvalds",
        'date'   => '2016-12-01 13:35:00'
    ],
    [
        'id'     => 3,
        'userId' => 2,
        'text'   => "Beware of bugs in the above code; I have only proved it correct, not tried it. -- Donald E. Knuth",
        'date'   => '2016-12-01 17:50:00'
    ],
    [
        'id'     => 4,
        'userId' => 1,
        'text'   => "To iterate is human, to recurse divine. -- L. Peter Deutsch",
        'date'   => '2016-12-02 11:15:00'
    ],
    [
        'id'     => 5,
        'userId' => 2,
        'text'   => "Good design adds value faster than it adds cost. -- Thomas C. Gale",
        'date'   => '2016-12-02 12:45:00'
    ],
    [
        'id'     => 6,
        'userId' => 2,
        'text'   => "C is quirky, flawed, and an enormous success. -- Dennis M. Ritchie",
        'date'   => '2016-12-03 12:35:00'
    ],
    [
        'id'     => 7,
        'userId' => 2,
        'text'   => "It is easier to port a shell than a shell script. -- Larry Wall",
        'date'   => '2016-12-03 19:45:00'
    ],
    [
        'id'     => 8,
        'userId' => 2,
        'text'   => "I invented the term 'Object-Oriented', and I can tell you I did not have C++ in mind. -- Thomas C. Gale",
        'date'   => '2016-12-04 10:03:00'
    ],
    [
        'id'     => 9,
        'userId' => 2,
        'text'   => "The trouble with programmers is that you can never tell what a programmer is doing until it’s too late. -- Seymour Cray",
        'date'   => '2016-12-05 14:13:00'
    ],
    [
        'id'     => 10,
        'userId' => 2,
        'text'   => "When in doubt, use brute force. -- Ken Thompson",
        'date'   => '2016-12-05 20:00:00'
    ],
    [
        'id'     => 11,
        'userId' => 2,
        'text'   => "Deleted code is debugged code. -- Jeff Sickel",
        'date'   => '2016-12-06 09:12:00'
    ],
    [
        'id'     => 12,
        'userId' => 2,
        'text'   => "Life is too short to run proprietary software. -- Bdale Garbee",
        'date'   => '2016-12-06 13:50:00'
    ],
    [
        'id'     => 13,
        'userId' => 2,
        'text'   => "Simplicity is prerequisite for reliability. -- Edsger W. Dijkstra",
        'date'   => '2016-12-07 15:05:00'
    ],
    [
        'id'     => 14,
        'userId' => 2,
        'text'   => "Simplicity is the ultimate sophistication. -- Leonardo da Vinci",
        'date'   => '2016-12-07 16:40:00'
    ],
];