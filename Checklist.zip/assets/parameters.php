<?php

/**
 * We define some parameters that can be later referenced in the configuration.
 *
 * You can use this to keep all environment specific variables,
 * like database credentials etc. in one file.
 */
return [
    'database' => [
        'name'     => 'phpixietest',
        'user'     => 'phpixietest',
        'password' => 'phpixietest'
    ],

    'social' => [
        'facebookId'     => 'YOUR APP ID',
        'facebookSecret' => 'YOUR APP SECRET',

        'twitterId'     => 'YOUR APP ID',
        'twitterSecret' => 'YOUR APP SECRET',

        'googleId'     => '637539339565-1gsmspsupcae097237djij5n3qseml9d.apps.googleusercontent.com',
        'googleSecret' => 'wlQgOOk6ev83V-YrIq1KHdUm',

        'vkId'     => '7831251',
        'vkSecret' => 'zY5ebTtn3jzXvICwghqA',
    ]
];