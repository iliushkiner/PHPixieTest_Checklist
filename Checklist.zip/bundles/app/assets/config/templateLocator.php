<?php

return array(
    'type'      => 'directory',
    'directory' => 'templates'
);